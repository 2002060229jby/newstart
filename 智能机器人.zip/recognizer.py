import speech_recognition as sr
# # Use SpeechRecognition to record 使用语音识别包录制音频
def my_record():
    rate = 16000   #录音参数必须满足 16k 采样率
    r = sr.Recognizer()  #实例化一个识别器r
    with sr.Microphone(sample_rate=rate) as source:   # 打开麦克风  句柄 source
        print("please say something")
        audio = r.listen(source)    #通过麦克风进行录音

    with open("./myvoices.wav", "wb") as f:  #设置文件名，类型
        f.write(audio.get_wav_data())             #将录音数据转换成wav格式写入文件
    print("录音完成！")
my_record()
