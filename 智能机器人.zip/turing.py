# 与机器人对话：调用的是图灵机器人
import requests
import json

# 图灵机器人的API_KEY、API_URL
turing_api_key = "75854c5f9e6d4be"
api_url = "http://openapi.tuling123.com/openapi/api/v2"  # 图灵机器人api网址
headers = {'Content-Type': 'application/json;charset=UTF-8'}

# 图灵机器人回复
def Turing(text_words=""):
    #请求
    req = {
        "reqType": 0,       # 输入类型 为文本
        "perception": {
            "inputText": {
                "text": text_words    # 输入文本信息
            },

            "selfInfo": {             # 客户端属性
                "location": {
                    "city": "新干县",
                    "province": "江西省",
                    "street": "善政二路"
                }
            }
        },
        #用户参数
        "userInfo": {
            "apiKey": turing_api_key,  # 你的图灵机器人apiKey
            "userId": "cheney007"  # 用户唯一标识(随便填, 非密钥)
        }
    }

    req["perception"]["inputText"]["text"] = text_words  #给json串赋值
    response = requests.request("post", api_url, json=req, headers=headers) #向接口网站发送请求
    print(response.status_code)
    response_dict = json.loads(response.text)

    result = response_dict["results"][0]["values"]["text"]  #得到接口的回复进行解析
    print("AI Robot said: " + result)
    return result
 
